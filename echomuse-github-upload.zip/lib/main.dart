import 'package:flutter/material.dart';

void main() {
  runApp(const EchoMuseApp());
}

class EchoMuseApp extends StatelessWidget {
  const EchoMuseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EchoMuse AI',
      theme: ThemeData.dark(),
      home: Scaffold(
        body: Center(child: Text('Welcome to EchoMuse AI')),
      ),
    );
  }
}
